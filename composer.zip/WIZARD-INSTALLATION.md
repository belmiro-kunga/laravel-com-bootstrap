# 🚀 Wizard de Instalação - Sistema de Denúncias

## 📋 Visão Geral

O Sistema de Denúncias agora inclui um **Wizard de Instalação** completo que facilita a configuração inicial do sistema. O wizard é ativado automaticamente quando o sistema não está instalado e guia o usuário através de um processo simples e intuitivo.

## 🔧 Funcionalidades

### ✅ **Verificação Automática**
- Detecta se o sistema está instalado
- Redireciona automaticamente para o wizard se necessário
- Bloqueia acesso ao wizard após instalação

### 📋 **Verificação de Requisitos**
- Versão do PHP (8.1+)
- Extensões PHP necessárias
- Permissões de diretórios
- Validação completa do ambiente

### 🗄️ **Configuração de Banco de Dados**
- Interface intuitiva para configuração MySQL
- Teste de conexão em tempo real
- Validação de credenciais
- Dicas específicas para diferentes provedores

### ⚙️ **Configuração do Sistema**
- Nome da aplicação
- URL do sistema
- Configurações do site
- Criação do usuário administrador

### 🔄 **Instalação Automática**
- Execução de migrações
- Criação de dados padrão
- Configuração de caches
- Otimização do sistema

## 🎯 **Como Usar**

### **1. Primeira Execução**
```bash
# Acesse o sistema
http://seudominio.com

# O wizard será ativado automaticamente
http://seudominio.com/install
```

### **2. Passos do Wizard**
1. **Bem-vindo** - Informações sobre o sistema
2. **Requisitos** - Verificação do ambiente
3. **Banco de Dados** - Configuração MySQL
4. **Configuração** - Dados do sistema e admin
5. **Instalação** - Processo automático
6. **Conclusão** - Sistema pronto para uso

### **3. Após a Instalação**
```bash
# Remover o wizard (recomendado para produção)
php artisan install:remove-wizard
```

## 🔒 **Segurança**

### **Proteções Implementadas**
- ✅ Verificação de instalação
- ✅ Middleware de proteção
- ✅ Validação de dados
- ✅ Sanitização de inputs
- ✅ Proteção CSRF

### **Recomendações**
- 🔒 Remova o wizard após instalação
- 🔒 Configure HTTPS
- 🔒 Altere senhas padrão
- 🔒 Faça backup regular

## 📁 **Estrutura de Arquivos**

```
app/
├── Http/
│   ├── Controllers/
│   │   └── InstallController.php
│   └── Middleware/
│       └── CheckInstallation.php
├── Console/Commands/
│   └── RemoveInstallWizard.php

routes/
└── install.php

resources/views/install/
├── layout.blade.php
├── welcome.blade.php
├── requirements.blade.php
├── database.blade.php
├── configure.blade.php
└── complete.blade.php
```

## 🎨 **Interface**

### **Design Responsivo**
- ✅ Bootstrap 5
- ✅ Font Awesome Icons
- ✅ Gradientes modernos
- ✅ Animações suaves
- ✅ Indicador de progresso

### **UX/UI**
- ✅ Interface intuitiva
- ✅ Validação em tempo real
- ✅ Feedback visual
- ✅ Dicas contextuais
- ✅ Modais informativos

## 🔧 **Configuração Avançada**

### **Personalização**
```php
// Em InstallController.php
protected $requirements = [
    'php' => '8.1.0',
    'extensions' => [
        'BCMath', 'Ctype', 'JSON', 'Mbstring',
        'OpenSSL', 'PDO', 'Tokenizer', 'XML',
        'Fileinfo', 'GD'
    ],
    'writable_dirs' => [
        'storage/app', 'storage/framework',
        'storage/logs', 'bootstrap/cache', '.env'
    ]
];
```

### **Extensões**
```php
// Adicionar novos requisitos
'extensions' => [
    // ... extensões existentes
    'curl', 'zip', 'gd'
]
```

## 🚀 **Deploy**

### **Hostinger**
1. Upload dos arquivos
2. Acesse o domínio
3. Siga o wizard
4. Configure banco de dados
5. Crie usuário admin
6. Sistema pronto!

### **Outros Provedores**
- Funciona em qualquer hospedagem PHP
- Suporte a MySQL/MariaDB
- Configuração automática

## 📞 **Suporte**

### **Problemas Comuns**
1. **Erro de permissões** - Configure 755/775
2. **Extensão faltando** - Contate o provedor
3. **Banco não conecta** - Verifique credenciais
4. **Wizard não aparece** - Verifique arquivo .env

### **Logs**
```bash
# Logs de instalação
storage/logs/laravel.log

# Verificar status
php artisan install:status
```

## 🎉 **Benefícios**

### **Para Desenvolvedores**
- ✅ Instalação simplificada
- ✅ Menos suporte técnico
- ✅ Deploy mais rápido
- ✅ Menos erros de configuração

### **Para Usuários**
- ✅ Interface amigável
- ✅ Processo guiado
- ✅ Validação automática
- ✅ Configuração sem código

---

**🎯 O Wizard de Instalação torna o deploy do Sistema de Denúncias muito mais simples e profissional!** 